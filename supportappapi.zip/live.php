<iframe
  src="https://player.vdocipher.com/live?liveId=85a33b57196540b0a2d6b496d1e389a0"
  style="border:0;width:720px;aspect-ratio:16/9;max-width:100%;"
  allow="autoplay,fullscreen"
  allowfullscreen
></iframe>