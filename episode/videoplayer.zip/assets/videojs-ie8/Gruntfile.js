require('babel/register');

module.exports = function(grunt) {
  require('./grunt.js')(grunt);
};
