# videojs-ie8
Video.js files for IE8 compatibility
